/*===============================================================================
Copyright (c) 2016 PTC Inc. All Rights Reserved.

Copyright (c) 2012-2014 Qualcomm Connected Experiences, Inc. All Rights Reserved.

Vuforia is a trademark of PTC Inc., registered in the United States and other 
countries.
===============================================================================*/

#include <jni.h>
#include <android/log.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <sys/time.h>
#include <math.h>

#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>

#include <Vuforia/Vuforia.h>
#include <Vuforia/UpdateCallback.h>
#include <Vuforia/CameraDevice.h>
#include <Vuforia/Renderer.h>
#include <Vuforia/VideoBackgroundConfig.h>
#include <Vuforia/Trackable.h>
#include <Vuforia/TrackableResult.h>
#include <Vuforia/ImageTargetResult.h>
#include <Vuforia/VirtualButtonResult.h>
#include <Vuforia/Tool.h>
#include <Vuforia/Tracker.h>
#include <Vuforia/TrackerManager.h>
#include <Vuforia/ObjectTracker.h>
#include <Vuforia/CameraCalibration.h>
#include <Vuforia/ImageTarget.h>
#include <Vuforia/VirtualButton.h>
#include <Vuforia/Rectangle.h>
#include <Vuforia/DataSet.h>

#include <Cube.h>
#include <CubeShaders.h>
#include <SampleUtils.h>
#include <SampleMath.h>
#include <Texture.h>


#define MAX_DOMINOES 100
#define DOMINO_TILT_SPEED 300.0f
#define MAX_TAP_TIMER 200
#define MAX_TAP_DISTANCE2 400


enum ActionType {
    ACTION_DOWN,
    ACTION_MOVE,
    ACTION_UP,
    ACTION_CANCEL
};

enum DominoState {
    DOMINO_STANDING,
    DOMINO_FALLING,
    DOMINO_RESTING
};


typedef struct _TouchEvent {
    bool isActive;
    int actionType;
    int pointerId;
    float x;
    float y;
    float lastX;
    float lastY;
    float startX;
    float startY;
    float tapX;
    float tapY;
    unsigned long startTime;
    unsigned long dt;
    float dist2;
    bool didTap;
} TouchEvent;

typedef struct _LLNode {
    int id;
    _LLNode* next;
} LLNode;

typedef struct _Domino {
    int id;
    int state;
    
    LLNode* neighborList;
    
    Vuforia::Vec2F position;
    float pivotAngle;
    float tiltAngle;
    Vuforia::Matrix44F transform;
    Vuforia::Matrix44F pickingTransform;
    
    int tippedBy;
    int restingFrameCount;
} Domino;

class VirtualButton_UpdateCallback : public Vuforia::UpdateCallback {
    virtual void Vuforia_onUpdate(Vuforia::State& state);
} vuforiaUpdate;


JavaVM* javaVM;
jobject javaObj;
jclass javaClass;

jmethodID jmethod_playSound;
jmethodID jmethod_showDeleteButton;
jmethodID jmethod_hideDeleteButton;
jmethodID jmethod_enableStartButton;
jmethodID jmethod_disableStartButton; 
jmethodID jmethod_toggleStartButton;
jmethodID jmethod_displayMessage;

bool displayedMessage;

unsigned long lastSystemTime;
unsigned long lastTapTime;

Vuforia::Matrix44F modelViewMatrix;

TouchEvent touch1, touch2;
bool simulationRunning;
bool shouldResetDominoes;
bool shouldClearDominoes;
bool shouldDeleteSelectedDomino;
bool shouldClearSelectedDomino;

Domino dominoArray[MAX_DOMINOES];
int dominoCount;
int uniqueId;

int dropStartIndex;
Vuforia::Vec2F lastDropPosition(0, 0);

Domino* selectedDomino;
int selectedDominoIndex;

Vuforia::Vec3F dominoBaseVertices[8];
Vuforia::Vec3F dominoTransformedVerticesA[8];
Vuforia::Vec3F dominoTransformedVerticesB[8];
Vuforia::Vec3F dominoNormals[3];

bool shouldUpdateButton;
bool shouldAddButton;
bool shouldMoveButton;
bool shouldEnableButton;
bool shouldDisableButton;
bool shouldRemoveButton;

Domino* vbDomino;


#ifdef __cplusplus
extern "C"
{
#endif
    
    // Cube texture:
    extern int textureCount;
    extern Texture** textures;
    
    // OpenGL ES 2.0 specific:
    extern unsigned int shaderProgramID;
    extern GLint vertexHandle;
    extern GLint normalHandle;
    extern GLint textureCoordHandle;
    extern GLint mvpMatrixHandle;
    extern GLint texSampler2DHandle;
    
    extern int screenWidth;
    extern int screenHeight;
    
    extern Vuforia::Matrix44F projectionMatrix;
    extern Vuforia::Matrix44F inverseProjMatrix;
    
    extern GLfloat viewport[4];

    extern Vuforia::DataSet* dataSet;

    JNIEXPORT jint JNICALL
    JNI_OnLoad(JavaVM* vm, void* nReserved);
    
    JNIEXPORT void JNICALL
    Java_com_vuforia_samples_Dominoes_Dominoes_onVuforiaInitializedNative(JNIEnv* env, jobject);
    
    JNIEXPORT void JNICALL
    Java_com_vuforia_samples_Dominoes_DominoesRenderer_initNativeCallback(JNIEnv* env, jobject obj);
    
    JNIEXPORT void JNICALL
    Java_com_vuforia_samples_Dominoes_DominoesRenderer_renderFrame(JNIEnv*, jobject);
    
    JNIEXPORT void JNICALL
    Java_com_vuforia_samples_Dominoes_Dominoes_nativeTouchEvent(JNIEnv*, jobject, jint actionType, jint pointerId, jfloat x, jfloat y);
    
    JNIEXPORT void JNICALL
    Java_com_vuforia_samples_Dominoes_GUIManager_nativeStart(JNIEnv*, jobject);
    
    JNIEXPORT void JNICALL
    Java_com_vuforia_samples_Dominoes_GUIManager_nativeReset(JNIEnv*, jobject);
    
    JNIEXPORT void JNICALL
    Java_com_vuforia_samples_Dominoes_GUIManager_nativeClear(JNIEnv*, jobject);
    
    JNIEXPORT void JNICALL
    Java_com_vuforia_samples_Dominoes_GUIManager_nativeDelete(JNIEnv*, jobject);
    
#ifdef __cplusplus
}
#endif

void playSoundEffect(int soundIndex, float volume = 1.0f);
void showDeleteButton();
void hideDeleteButton();
void toggleStartButton();
void displayMessage(char* message);

void updateAugmentation(const Vuforia::Trackable* trackable, float dt);
void handleTouches();
void renderAugmentation(const Vuforia::Trackable* trackable);
void renderCube(float* transform);

void addVirtualButton();
void removeVirtualButton();
void moveVirtualButton(Domino* domino);
void enableVirtualButton();
void disableVirtualButton();

void initDominoBaseVertices();
void initDominoNormals();

bool canDropDomino(Vuforia::Vec2F position);
void dropDomino(Vuforia::Vec2F position);
void updateDominoTransform(Domino* domino);
void updatePickingTransform(Domino* domino);

void runSimulation(Domino* domino, float dt);
void handleCollision(Domino* domino, Domino* otherDomino, float originalTilt);
void adjustPivot(Domino* domino, Domino* otherDomino);
Domino* getDominoById(int id);

void resetDominoes();
void clearDominoes();
void setSelectedDomino(Domino* domino);
void deleteSelectedDomino();

void projectScreenPointToPlane(Vuforia::Vec2F point, Vuforia::Vec3F planeCenter, Vuforia::Vec3F planeNormal,
                               Vuforia::Vec3F &intersection, Vuforia::Vec3F &lineStart, Vuforia::Vec3F &lineEnd);
bool linePlaneIntersection(Vuforia::Vec3F lineStart, Vuforia::Vec3F lineEnd, Vuforia::Vec3F pointOnPlane,
                           Vuforia::Vec3F planeNormal, Vuforia::Vec3F &intersection);

bool checkIntersection(Vuforia::Matrix44F transformA, Vuforia::Matrix44F transformB);
bool isSeparatingAxis(Vuforia::Vec3F axis);

bool checkIntersectionLine(Vuforia::Matrix44F transformA, Vuforia::Vec3F pointA, Vuforia::Vec3F pointB);
bool isSeparatingAxisLine(Vuforia::Vec3F axis, Vuforia::Vec3F pointA, Vuforia::Vec3F pointB);

JNIEnv* getJNIEnv();
unsigned long getCurrentTimeMS();
